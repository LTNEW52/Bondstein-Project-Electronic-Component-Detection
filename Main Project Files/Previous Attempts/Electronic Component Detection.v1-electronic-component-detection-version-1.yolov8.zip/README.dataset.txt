# Electronic Component Detection > Electronic Component Detection Version 1
https://universe.roboflow.com/labib-projects/electronic-component-detection-r2mbp

Provided by a Roboflow user
License: CC BY 4.0

